package com.testclasses;
import rebit.pm.training.currencymgtapp.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertNotNull;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FileHandlingTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
