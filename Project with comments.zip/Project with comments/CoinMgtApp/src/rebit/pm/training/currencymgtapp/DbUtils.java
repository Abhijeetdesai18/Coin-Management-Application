package rebit.pm.training.currencymgtapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtils {
	private static Connection connection;
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "Admin@123";
	private static final String CONNECTIONURL = "jdbc:mysql://localhost:3306/coin_mgt_app";

	// Method to initialize the database connection
	public static void initializeDatabase() {
		try {
			Class.forName(DRIVER);  // Load the MySQL driver
			connection = DriverManager.getConnection(CONNECTIONURL, USERNAME, PASSWORD); // Establish a connection to the database
		} catch (Exception e) {
			throw new RuntimeException("Failed to Connect."); // Handle any exceptions and indicate a failure to connect
		}
	}

	// Method to get the database connection
	public static Connection getConnection() {
		if (connection == null) {
			throw new IllegalStateException("Database connection not established."); // Check if the connection is null and throw an exception if not established
		}
		return connection;
	}

	// Method to close the database connection
	public static void closeConnection() {
		try {
			if (connection != null) {
				connection.close(); // Close the database connection if it's not null
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Handle any SQLException that may occur during the close operation
		}
	}

	// Method to close an AutoCloseable resource 
	public static void closeResource(AutoCloseable resource) {
		if (resource != null) {
			try {
				resource.close(); // Close the provided AutoCloseable resource
			} catch (Exception e) {
				e.printStackTrace(); // Handle any exceptions that may occur during the close operation
			}
		}
	}
}
